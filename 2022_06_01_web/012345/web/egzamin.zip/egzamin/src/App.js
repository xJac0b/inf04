import 'bootstrap/dist/css/bootstrap.css';
import { useState } from 'react';


function App()
{
  const kursy = ["Programowanie w C#", "Angular dla początkujących", "Kurs Django"]
  const [imie, ustawImie] = useState('')
  const [kursIndeks, ustawKursIndeks] = useState()

  const onSubmit = (e) => {
    e.preventDefault();
    let kursLog = (kursIndeks < 0 || kursIndeks >= kursy.length || kursy[kursIndeks] === undefined) ? "Nieprawidłowy numer kursu" : kursy[kursIndeks]

    console.log(`${imie}\n${kursLog}`)
  }

  return (
    <div className='container'>
      <h2>Liczba kursów: {kursy.length}</h2>
      <ol>
      {
        kursy.map((e) => <li>{e}</li>)
      }
      </ol>
      <form onSubmit={onSubmit}>
      <div class='col'>
        <label htmlFor="imieNazwisko">Imię i nazwisko</label>
        <input id="imieNazwisko" onChange={e=>ustawImie(e.target.value)} className="mt-1 form-control"></input>
        <label htmlFor="numerKursu" className="mt-2">Numer kursu:</label>
        <input id="numerKursu" type="number" onChange={e=>ustawKursIndeks(e.target.value)} className='mt-1 form-control'></input>
        <button className='btn btn-primary mt-3'>Zapisz do kursu</button>
        </div>
      </form>
    </div>
  )
}

export default App;