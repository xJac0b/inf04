﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace GraKosci
{
    public partial class MainPage : ContentPage
    {
        private int wynikGry = 0;
        public MainPage()
        {
            InitializeComponent();
        }

        private void Button_Clicked(object sender, EventArgs e)
        {
            int[] wynikLosowania = Losuj();

            int sumaPunktow = LiczPunkty(wynikLosowania);

            wynikGry += sumaPunktow;
            wynikGryLabel.Text = "Wynik gry: " + wynikGry;
            wynikLosowaniaLabel.Text = "Wynik losowania: " + sumaPunktow;

        }
        private int[] Losuj()
        {
            int[] wynik = new int[5];
            Random rand = new Random();

            for (int i = 0; i < 5; i++)
            {
                wynik[i] = rand.Next(1, 7);
            }

            obraz1.Source = "_" + wynik[0] + ".jpg";
            obraz2.Source = "_" + wynik[1] + ".jpg";
            obraz3.Source = "_" + wynik[2] + ".jpg";
            obraz4.Source = "_" + wynik[3] + ".jpg";
            obraz5.Source = "_" + wynik[4] + ".jpg";

            return wynik;
        }

        private int LiczPunkty(int[] oczka)
        {
            int suma = 0;
            int[] licznikOczek = new int[7];
            for (int i = 0; i < oczka.Length; i++)
            {
                licznikOczek[oczka[i]]++;
            }

            for (int i = 0; i < oczka.Length; i++)
            {
                if (licznikOczek[oczka[i]] > 1)
                {
                    suma += oczka[i];
                }
            }
            return suma;
        }

        private void Button_Clicked_1(object sender, EventArgs e)
        {
            obraz1.Source = "question.jpg";
            obraz2.Source = "question.jpg";
            obraz3.Source = "question.jpg";
            obraz4.Source = "question.jpg";
            obraz5.Source = "question.jpg";

            wynikGry = 0;

            wynikGryLabel.Text = "Wynik gry: 0";
            wynikLosowaniaLabel.Text = "Wynik losowania: 0";
        }
    }
}
