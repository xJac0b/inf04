﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace Logowanie
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void Button_Clicked(object sender, EventArgs e)
        {
            if (!poleEmail.Text.Contains('@'))
            {
                komunikat.Text = "Nieprawidłowy adres e - mail";
                return;
            }
            if(poleHaslo.Text != polePowtorzHaslo.Text)
            {
                komunikat.Text = "Hasła się różnią";
                return;
            }
            komunikat.Text = "Witaj " + poleEmail.Text;
        }
    }
}
